module.exports =  {
  "wl": "http://wanderers-library.wikidot.com",
  "en": "http://scp-wiki.wikidot.com",
  "ru": "http://scp-ru.wikidot.com",
  "ko": "http://scpko.wikidot.com",
  "ja": "http://scp-jp.wikidot.com",
  "fr": "http://fondationscp.wikidot.com",
  "es": "http://lafundacionscp.wikidot.com",
  "th": "http://scp-th.wikidot.com",
  "pl": "http://scp-pl.wikidot.com",
  "de": "http://scp-wiki-de.wikidot.com",
  "cn": "http://scp-wiki-cn.wikidot.com",
  "it": "http://fondazionescp.wikidot.com",
  "pt": "http://scp-pt-br.wikidot.com",
  "cz": "http://scp-cs.wikidot.com",
  "int": "http://scp-int.wikidot.com"
};

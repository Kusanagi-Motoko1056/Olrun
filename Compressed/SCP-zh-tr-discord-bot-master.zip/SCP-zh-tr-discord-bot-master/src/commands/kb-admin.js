module.exports.run = (bot, message, args) => {
    bot.destroy();
}

module.exports.help = {
  name:"kb"
}
